#ifndef ETHERNET_COMP_H
#define ETHERNET_COMP_H

#define Ethernet UIPEthernet
#define EthernetClient UIPClient
#define EthernetServer UIPServer
#define EthernetUDP UIPUDP

#endif
